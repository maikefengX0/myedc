	package com.jikexueyuan.tulingdemo;
import android.app.Application;
import android.graphics.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.content.Context;
import android.hardware.camera2.CameraManager;


public class OpenTorch {

	/*
	
	
  void openTorch1(){
	  
	  Camera camera = Camera.open();
	  
	  if(OPEN){
		  
		  Parameters mParameters = camera.getParameters();
		  
		  mParameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
		  
		  camera.setParameters(mParameters);
		  
		  } else {
		  
		  Parameters mParameters = camera.getParameters();
		  
		  mParameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
		  
		  camera.setParameters(mParameters);
		  
	  }
	  
	  camera.release();
	
	
	
}
	
*/	


	void openTorch2(Context context){
		
		boolean OPEN=true;
		
		try {
			
			//获取CameraManager
			//CameraManager  mCameraManager
			//= (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
			
			//mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
			
	
		CameraManager mCameraManager = (CameraManager) context
		.getSystemService(Context.CAMERA_SERVICE);
			
			//获取当前手机所有摄像头设备ID
			
			String[] ids = mCameraManager.getCameraIdList();
			
			for (String id : ids) {
				
				CameraCharacteristics c = mCameraManager.getCameraCharacteristics(id);
				
				//查询该摄像头组件是否包含闪光灯
				
				Boolean flashAvailable = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
				
				/*
				
				* 获取相机面对的方向
				
				* CameraCharacteristics.LENS_FACING_FRONT 前置摄像头
				
				* CameraCharacteristics.LENS_FACING_BACK 后只摄像头
				
				* CameraCharacteristics.LENS_FACING_EXTERNAL 外部的摄像头
				
				*/
				
				Integer lensFacing = c.get(CameraCharacteristics.LENS_FACING);
				
				if (flashAvailable != null && flashAvailable
				
				&& lensFacing != null && lensFacing == CameraCharacteristics.LENS_FACING_BACK) {
					
					//打开或关闭手电筒
					
					mCameraManager.setTorchMode(id, OPEN? true:false);
					
				}
				
			}
			
			} catch (CameraAccessException e) {
			
			e.printStackTrace();
			
		}
	}
	
	
}