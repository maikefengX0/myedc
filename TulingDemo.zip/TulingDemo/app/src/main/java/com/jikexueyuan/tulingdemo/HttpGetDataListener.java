package com.jikexueyuan.tulingdemo;

public interface HttpGetDataListener {

	void getDataUrl(String data);
}
