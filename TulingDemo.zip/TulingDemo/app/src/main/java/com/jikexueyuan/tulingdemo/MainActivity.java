package com.jikexueyuan.tulingdemo;

import android.app.PendingIntent;
import android.app.AlarmManager;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraCharacteristics;
import android.icu.util.Calendar;
import android.hardware.camera2.CameraAccessException;
import android.os.Vibrator;
import com.jikexueyuan.tulingdemo.Torch;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.text.format.Formatter;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends Activity implements HttpGetDataListener,
OnClickListener {
	
	private HttpData httpData;
	private List<ListData> lists;
	private ListView lv;
	private EditText sendtext;
	private Button send_btn;
	private String content_str;
	private TextAdapter adapter;
	private String[] welcome_array;
	private double currentTime=0, oldTime = 0;
private Torch opensh;
private Context context = this;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();
	}
	
	private void initView() {
		lv = (ListView) findViewById(R.id.lv);
		sendtext = (EditText) findViewById(R.id.sendText);
		send_btn = (Button) findViewById(R.id.send_btn);
		lists = new ArrayList<ListData>();
		send_btn.setOnClickListener(this);
		adapter = new TextAdapter(lists, this);
		lv.setAdapter(adapter);
		ListData listData;
		listData = new ListData(getRandomWelcomeTips(), ListData.RECEIVER,
		getTime());
		lists.add(listData);
	}
	
	private String getRandomWelcomeTips() {
		String welcome_tip = null;
		welcome_array = this.getResources()
		.getStringArray(R.array.welcome_tips);
		int index = (int) (Math.random() * (welcome_array.length - 1));
		welcome_tip = welcome_array[index];
		return welcome_tip;
	}
	
	@Override
	public void getDataUrl(String data) {
		// System.out.println(data);
		parseText(data);
	}
	
	public void parseText(String str) {
		try {
			JSONObject jb = new JSONObject(str);
			// System.out.println(jb.getString("code"));
			// System.out.println(jb.getString("text"));
			ListData listData;
			listData = new ListData(jb.getString("text"), ListData.RECEIVER,
			getTime());
			lists.add(listData);
			adapter.notifyDataSetChanged();
			} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void onClick(View v) {
		getTime();
		content_str = sendtext.getText().toString();
		sendtext.setText("");
		String dropk = content_str.replace(" ", "");
		String droph = dropk.replace("\n", "");
		ListData listData;
		listData = new ListData(content_str, ListData.SEND, getTime());
		lists.add(listData);
		if (lists.size() > 30) {
			for (int i = 0; i < lists.size(); i++) {
				lists.remove(i);
			}
		}
		adapter.notifyDataSetChanged();
		oper(content_str
		);

		//httpData = (HttpData) new HttpData(
		//"http://www.tuling123.com/openapi/api?key=6af9822f5491fadfc142b53818bbd63a&info="
//		+ droph, this).execute();
	}

private void oper(String str){
String content="";	
	


	
if (str.equals("打开手电筒")
	) {
	
		
		boolean OPEN=true;
			openTorch2(context,OPEN);
		
		
		content="主人已为你打开手电筒";
		
	}	
	
if (str.equals("关闭手电筒")
) {

	
boolean OPEN=false;	
	
openTorch2(context,OPEN);	
	
	
	content="主人已为你关闭手电筒";
	
}
		
		if (str.equals("亮闪")
				
		) {
			
			for (int i = 10; i > 0; i--) {
				//循环语句块
				
				openTorch2(context,true);
				
				openTorch2(context,false);
			}
			
			
			
			
			
			
			
			content="主人已为你开启亮闪";
			
		}
		
		
		
		if (str.equals("震动")
		
		) {
			
			Vibrator  vv=(Vibrator) getApplication().getSystemService(Service.VIBRATOR_SERVICE);
			
			vv.vibrate(500);//震半秒钟
			
			long[] pattern = {0, 100, 1000, 300, 2000}; // 震动1s，停顿0.3s，震动2s
			vv.vibrate(pattern, 0); // 第二个参数0表示从数组的第一个元素开始
			
			content="主人已为你震动";
			
		}
		
		
		if (str.equals("停止震动")
		
		) {
			
			Vibrator  vv=(Vibrator) getApplication().getSystemService(Service.VIBRATOR_SERVICE);
			
			vv.cancel();
			
			content="已停止震动";
			
		}
		
		if (str.equals("闹钟")
		
		) {
		
		
		
		AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY,15);
		calendar.set(Calendar.MINUTE,35);
		calendar.set(Calendar.SECOND,00);//这里代表 21.14.00
		Intent intent = new Intent("Li_ALI");
		intent.putExtra("msg","阿力起床了啊");
		PendingIntent pi = PendingIntent.getBroadcast(this,0,intent,0);
		// 到了 21点14分00秒 后通过PendingIntent pi对象发送广播

		
		am.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),pi);
		
		content="已经启动闹钟";
		
	}
		
		
		
		
		

		


	
	
ListData listData;	
listData = new ListData(content
, ListData.RECEIVER,
	getTime());
	lists.add(listData);
	adapter.notifyDataSetChanged();	
	
}	
	
	
	private String getTime() {
		currentTime = System.currentTimeMillis();
		SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
		Date curDate = new Date();
		String str = format.format(curDate);
		if (currentTime - oldTime >= 500) {
			oldTime = currentTime;
			return str;
			} else {
			return "";
		}
		
	}
	
public void openTorch2(Context context,boolean OPEN){
		
		
		
		try {
			
			//获取CameraManager
			//CameraManager  mCameraManager
			//= (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
			
			//mCameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
			
			
			CameraManager mCameraManager = (CameraManager) context
			.getSystemService(Context.CAMERA_SERVICE);
			
			//获取当前手机所有摄像头设备ID
			
			String[] ids = mCameraManager.getCameraIdList();
			
			for (String id : ids) {
				
				CameraCharacteristics c = mCameraManager.getCameraCharacteristics(id);
				
				//查询该摄像头组件是否包含闪光灯
				
				Boolean flashAvailable = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
				
				/*
				
				* 获取相机面对的方向
				
				* CameraCharacteristics.LENS_FACING_FRONT 前置摄像头
				
				* CameraCharacteristics.LENS_FACING_BACK 后只摄像头
				
				* CameraCharacteristics.LENS_FACING_EXTERNAL 外部的摄像头
				
				*/
				
				Integer lensFacing = c.get(CameraCharacteristics.LENS_FACING);
				
				if (flashAvailable != null && flashAvailable
				
				&& lensFacing != null && lensFacing == CameraCharacteristics.LENS_FACING_BACK) {
					
					//打开或关闭手电筒
					
					mCameraManager.setTorchMode(id, OPEN? true:false);
					
				}
				
			}
			
			} catch (CameraAccessException e) {
			
			e.printStackTrace();
			
		}
	}
	
	

}